<?php

return [
    'site_title' => 'xndxcouture',
];
